package com.hcl.gl.dao;
import java.util.ArrayList;
import java.util.*;
import com.hcl.gl.exception.NegativeException;
import com.hcl.gl.pojo.Movie;

public class MovieDao 
{
	HashMap<String,Movie> map=new HashMap<String,Movie>();
	Scanner sc=new Scanner(System.in);
	Movie movies[];   //Movies movies=new Movies[size];
	int size,noOfMovies;
	
	public MovieDao(int noOfMovies)  //constructor
	{
	  size=0;
	  this.noOfMovies=noOfMovies;
	  movies=new Movie[noOfMovies];
	}
	
	//addMovie
	
	public void addMovie()
	{
		Movie movie=new Movie();
		System.out.println("Enter movieId: ");
		int id=sc.nextInt();sc.nextLine();
		movie.setMovieId(id);
		System.out.println("Enter movie name: ");
		String name=sc.nextLine();
		movie.setMovieName(name);
		System.out.println("Enter movie text: ");
		String text=sc.nextLine();
		movie.setMovieText(text);
		System.out.println("Enter movie category: ");
		String category=sc.nextLine();
		movie.setMovieCategory(category);
		//movie(id,name,text,category);
		map.put(name, movie);
		System.out.println("Movie added");
		movies[size]=movie;
		size++;
	}
	
	
	//updateMovie
	
	public void updateMovie() throws NegativeException             
	{
		int flag=0;  //status variable
		System.out.println("Enter the  Oldmovie name to be updated: ");
		String Name=sc.nextLine();   //OLD MOVIE NAME
		if(map.containsKey(Name))
		{
			
			for(Map.Entry<String,Movie> data:map.entrySet())
			{
				
				Movie m=data.getValue();
				if(data.getKey().equals(Name))
				{
					
					System.out.println("Enter the updated movie name: ");
					String updatedMovie=sc.nextLine(); 
					m.setMovieName(updatedMovie);
					map.remove(Name);
					map.put(updatedMovie, m);//changing
					System.out.println("Movie name updated");
					 flag=1;
					 break;	
				}	
			}
		}
		if(flag==0)
		{
			try
			{
			throw new NegativeException("Movie does not exist");
			}
			catch(NegativeException ne)
			{
				System.out.println("Please try again!");
			}
		}
	}
	
	//delete the movie 
	
	public void DeleteMovie() throws NegativeException             
	{
		int flag=0;  //status variable
		System.out.println("Enter the  movie name to be deleted: ");
		String Name=sc.nextLine();   //OLD MOVIE NAME
		if(map.containsKey(Name))
		{
				map.remove(Name);	
				System.out.println("Movie name deleted");
				 flag=1;
					
					
		}
		if(flag==0)
		{
			try
			{
			throw new NegativeException("Movie does not exist");
			}
			catch(NegativeException ne)
			{
				System.out.println("Please try again!");
			}
		}
	}
	
	
	
	//Search Movie
	
	public void searchMovie()throws NegativeException 
	{
		int flag=0;  //status variable
		System.out.println("Enter the movie name to be searched: ");
		String movieName=sc.nextLine();   //OLD MOVIE NAME
		
		if(map.containsKey(movieName))
		{
			for(Map.Entry<String,Movie> data:map.entrySet())
			{
				Movie m=data.getValue();
				if(m.getMovieName().equals(movieName))
				{
					//Movie m=data.getValue();
					System.out.println(m.getMovieId()+"  "+m.getMovieName()+"  "+m.getMovieText()+"  "+m.getMovieCategory()+"  "+m.getAssignedTo());
					 flag=1;
					 break;
				}	
			}
			if(flag==0)
			{
				try {
					throw new NegativeException("Movie could not be searched");
				}
				catch(NegativeException ne)
				{
					System.out.println("Please try again!");
				}
			}
		}
	}
	
	
	//asignn Movie
	
	public void assigneeMovie()throws NegativeException
	{
		int flag=0;  //status variable
		System.out.println("Enter the movie name to be be assigned to a user: ");
		String movieName=sc.nextLine();   //OLD MOVIE NAME
		if(map.containsKey(movieName))
		{
			for(Map.Entry<String, Movie> data:map.entrySet())
			{
				
				Movie m=data.getValue();
				if(m.getMovieName().equals(movieName))
				{
					System.out.println("Enter the name of the assignee user: ");
					String as=sc.nextLine();
					 m.setAssignedTo(as);
					 System.out.println("assigned");
					 flag=1;
					 break;
				}
			}
		}
		if(flag==0)
		{
			System.out.println("Movie does not exist");
		}
	}
	
	//view allMovies
	
	
	public void viewAllMovies()
	{
		for(Map.Entry<String,Movie> data:map.entrySet())
		{
			Movie m=data.getValue();
			System.out.println(m.getMovieId()+"  "+m.getMovieName()+"  "+m.getMovieText()+"  "+m.getMovieCategory()+"  "+m.getAssignedTo());
		}
	}

	
}
