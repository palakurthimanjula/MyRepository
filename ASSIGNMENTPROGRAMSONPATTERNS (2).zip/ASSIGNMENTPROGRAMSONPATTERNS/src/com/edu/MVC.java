package com.edu;
//Define the model class
class User1 {
 private Long id;
 private String name;
 private String email;

 
public User1(Long id, String name, String email) {
	super();
	this.id = id;
	this.name = name;
	this.email = email;
}

public Long getId() {
	return id;
}

public void setId(Long id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

 
}

//Define the view class
class UserView {
 public void printUserDetails(User1 user) {
     System.out.println("User details:");
     System.out.println("ID: " + user.getId());
     System.out.println("Name: " + user.getName());
     System.out.println("Email: " + user.getEmail());
 }
}

//Define the controller class
class UserController {
 private User1 model;
 private UserView view;

 

 public UserController(User1 model, UserView view) {
	super();
	this.model = model;
	this.view = view;
}



public void setModel(User1 model) {
	this.model = model;
}



public void setView(UserView view) {
	this.view = view;
}


public void updateUserView() {
     view.printUserDetails(model);
 }




}

//Example usage
public class MVC {
 public static void main(String[] args) {
	 // Create a new user
     User1 user = new User1(1L, "John", "john@example.com");

     // Create the view and controller
     UserView userView = new UserView();
     UserController userController = new UserController(user, userView);

     // Update the user name and email
     //userController.setUserName("Jane");
     //userController.setUserEmail("jane@example.com");

     // Update the view
     userController.updateUserView();
    
}
}
