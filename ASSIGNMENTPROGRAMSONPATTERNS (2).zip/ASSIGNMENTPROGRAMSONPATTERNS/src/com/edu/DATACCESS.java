package com.edu;

import java.util.ArrayList;
import java.util.List;

//Define the data access object interface
interface UserDao {
 User getUserById(Long id);
 void addUser(User user);
 void updateUser(User user);
 void deleteUser(User user);
}

//Define the entity class
class User2 {
 private Long id;
 private String name;
 private String email;

 public User2(Long id, String name, String email) {
     this.id = id;
     this.name = name;
     this.email = email;
 }

 public Long getId() {
     return id;
 }

 public void setId(Long id) {
     this.id = id;
 }

 public String getName() {
     return name;
 }

 public void setName(String name) {
     this.name = name;
 }

 public String getEmail() {
     return email;
 }

 public void setEmail(String email) {
     this.email = email;
 }
}

//Define the concrete implementation of the data access object interface
class UserDaoImpl implements UserDao {
 private List<User> users = new ArrayList<>();

 public User getUserById(Long id) {  //select * from user where userid=1;
     for (User user : users) {
         if (user.getId().equals(id)) {
             return user;
         }
     }
     return null;
 }

 public void addUser(User user) {
     users.add(user);
 }

 public void updateUser(User user) {
     User existingUser = getUserById(user.getId());
     if (existingUser != null) {
         existingUser.setName(user.getName());
         existingUser.setEmail(user.getEmail());
     }
 }

 public void deleteUser(User user) {
     users.remove(user);
 }
}

//Example usage
public class DATACCESS {
 public static void main(String[] args) {
	 UserDao userDao = new UserDaoImpl();

     // Add a new user
     User user1 = new User(1L, "John", "john@example.com");
     userDao.addUser(user1);

     // Update user information
     User userToUpdate = userDao.getUserById(1L);
     userToUpdate.setName("Jane");
     userToUpdate.setEmail("jane@example.com");
     userDao.updateUser(userToUpdate);

     // Delete the user
     User userToDelete = userDao.getUserById(1L);
     userDao.deleteUser(userToDelete);

     // Check if the user has been deleted
     User deletedUser = userDao.getUserById(1L);
     if (deletedUser == null) {
         System.out.println("User has been deleted");
     } else {
    	 System.out.println("User still exists");
      }
     }
}


