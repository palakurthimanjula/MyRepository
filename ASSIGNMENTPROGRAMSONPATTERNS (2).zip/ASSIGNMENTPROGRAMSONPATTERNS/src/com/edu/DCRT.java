package com.edu;

import java.util.Scanner;

//Define the interface for the component and its concrete implementation
interface Pizza {
 String getDescription();
 double getCost();
}

class BasicPizza implements Pizza {
 public String getDescription() {
     return "Pizza";
 }
 public double getCost() {
     return 10.0;
 }
}

//Define the decorator class and its concrete implementations
abstract class ToppingDecorator implements Pizza {
 protected Pizza pizza;

 public ToppingDecorator(Pizza pizza) {
     this.pizza = pizza;
 }

 public String getDescription() {
     return pizza.getDescription();
 }
 public double getCost() {
     return pizza.getCost();
 }
}

class Cheese extends ToppingDecorator {
 public Cheese(Pizza pizza) {
     super(pizza);
 }

 public String getDescription() {
     return pizza.getDescription() + ", Cheese";
 }

 public double getCost() {
     return pizza.getCost() + 2.0;
 }
}

class Pepperoni extends ToppingDecorator {
 public Pepperoni(Pizza pizza) {
     super(pizza);
 }

 public String getDescription() {
     return pizza.getDescription() + ", Pepperoni";
 }

 public double getCost() {
     return pizza.getCost() + 3.0;
 }
 
 public void getPizza() {
	 System.out.println();
 }
 
}
public class DCRT{
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		BasicPizza bob=new BasicPizza();
		System.out.println("Detains of Basic pizza");
		System.out.println(bob.getDescription());
		System.out.println(bob.getCost());
		
		System.out.println("Do you want toppings y/n");
		char ch=sc.next().charAt(0);
		if(ch=='y') {
			Cheese cob=new Cheese(bob);
			System.out.println(cob.getDescription());
			System.out.println(cob.getCost());
		}else {
			System.out.println("You will get Basic pizza");
		}
		
	}
}


