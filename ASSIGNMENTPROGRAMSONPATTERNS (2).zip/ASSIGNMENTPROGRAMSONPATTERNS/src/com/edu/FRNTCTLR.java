package com.edu;
//Define the front controller class
class FrontController {
 private Dispatcher dispatcher;

 public FrontController() {
     dispatcher = new Dispatcher();
 }

 private boolean isAuthenticated() {
     // Check if the user is authenticated
     return true;
 }

 private void trackRequest(String request) {
     // Log each request
     System.out.println("Request: " + request);
 }

 public void dispatchRequest(String request) {
     // Log each request
     trackRequest(request);

     // Authenticate the user
     if (isAuthenticated()) {
         // Dispatch the request to the appropriate component
         dispatcher.dispatch(request);
     } else {
         System.out.println("User is not authenticated");
     }
 }
}

//Define the dispatcher class
class Dispatcher {
 private View homeView;
 private View studentView;

 public Dispatcher() {
     homeView = new HomeView();
     studentView = new StudentView();
 }

 public void dispatch(String request) {
     if (request.equalsIgnoreCase("HOME")) {
         homeView.show();
     } else if (request.equalsIgnoreCase("STUDENT")) {
         studentView.show();
     } else {
         System.out.println("Invalid request");
     }
 }
}

//Define the view interface
interface View {
 void show();
}

//Define the concrete view classes
class HomeView implements View {
 public void show() {
     System.out.println("Displaying Home Page");
 }
}

class StudentView implements View {
 public void show() {
     System.out.println("Displaying Student Page");
 }
}
    