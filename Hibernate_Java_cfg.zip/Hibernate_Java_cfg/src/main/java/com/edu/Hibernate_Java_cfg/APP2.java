package com.edu.Hibernate_Java_cfg;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.test.hibernate.entity.Book;

public class APP2 
{
    private static final Session JavaConfig = null;

	public static void main( String[] args )
    {
    	
     SessionFactory sessionFactory=JavaConfig.getSessionFactory();
     Session session=sessionFactory.openSession();
     
     Transaction transaction=session.beginTransaction();
     
     //Create Validation Factory which returns validator
     ValidatorFactory validatorFactory=Validation.buildDefaultValidatorFactory();
     
     
     //It validates bean instance+ 
     Validator validator=validatorFactory.getValidator();
     
     
     Book book=new Book("Introduction to C++", 700, null, null, "ISBN3274773487");
     
     //validate bean
     Set<ConstraintViolation<Book>> constraintViolations=validator.validate(book);
     
     if(constraintViolations.size()>0)
     {
    	 System.out.println("Constraint violation");
    	 for(ConstraintViolation<Book> violation:constraintViolations)
    	 {
    		 System.out.println(violation.getMessage());
    	 }
    	 
    	 
     }
     
     else
     {
    	  session.save(book);
    	  transaction.commit(); 
     }
    	 
     
     
   
    	
     
     
    }
}