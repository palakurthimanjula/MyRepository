package com.edu.Hibernate_Java_cfg;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.test.hibernate.entity.Book;

public class App 
{
    private static final Session JavaConfig = null;

	public static void main( String[] args )
    {
    	try
    	{
     SessionFactory sessionFactory=JavaConfig.getSessionFactory();
     Session session=sessionFactory.openSession();
     
     Transaction transaction=session.beginTransaction();
     
     
     Book book=new Book("Introduction to Java", 800, "Computer", "James Gosling", "ISBN3274773487");
     
     session.save(book);
     
     
     transaction.commit();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    	}
     
     
    }
}