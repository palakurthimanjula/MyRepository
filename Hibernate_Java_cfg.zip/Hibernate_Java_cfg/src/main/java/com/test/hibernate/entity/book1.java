package com.test.hibernate.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class book1{
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY )
	private long id;
	
	@Column(nullable = false, length = 100) 
	private String name;
	
	@Column(nullable = false)
	private double price;
	
	@Column(length = 30)
	private String type;
	
	@Column(length = 50, nullable = false, updatable = true)
	private String author;
	
	@Column(unique = true)
	private String isbn;
	
	
	
	
	
	public book1() {
		super();
		// TODO Auto-generated constructor stub
	}




	public book1( String name, double price, String type, String author, String isbn) {
		
		this.name = name;
		this.price = price;
		this.type = type;
		this.author = author;
		this.isbn = isbn;
	}




	public long getId() {
		return id;
	}




	public void setId(long id) {
		this.id = id;
	}




	public String getName() {
		return name;
	}




	public void setName(String name) {
		this.name = name;
	}




	public double getPrice() {
		return price;
	}




	public void setPrice(double price) {
		this.price = price;
	}




	public String getType() {
		return type;
	}




	public void setType(String type) {
		this.type = type;
	}




	public String getAuthor() {
		return author;
	}




	public void setAuthor(String author) {
		this.author = author;
	}




	public String getIsbn() {
		return isbn;
	}




	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}




	@Override
	public String toString() {
		return "Book [id=" + id + ", name=" + name + ", price=" + price + ", type=" + type + ", author=" + author
				+ ", isbn=" + isbn + "]";
	}
	
	
	

}